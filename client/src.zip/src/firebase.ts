// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBxPj-ZvlvtCRofbDLx0-XP4JC0UXz4jyM",
  authDomain: "study-buddy-project-6e29c.firebaseapp.com",
  projectId: "study-buddy-project-6e29c",
  storageBucket: "study-buddy-project-6e29c.firebasestorage.app",
  messagingSenderId: "1486720499",
  appId: "1:1486720499:web:3ee407a482c82f7baed686"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);